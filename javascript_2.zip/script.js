let gomb = document.querySelector("#gomb");

function getRandomInt(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min) + min); //The maximum is exclusive and the minimum is inclusive
  }

function changeBgColor(){
    let red = getRandomInt(0, 256);
    let green = getRandomInt(0, 256);
    let blue = getRandomInt(0, 256);

    gomb.style = "background-color: rgb(" + red + "," + green + "," + blue + ")";
}

function changeShadowColor(){
    let red = getRandomInt(0, 256);
    let green = getRandomInt(0, 256);
    let blue = getRandomInt(0, 256);

    gomb.style = "box-shadow: 0 0 0 .25rem rgba(" + red + "," + green + "," + blue + ", .5) !important";
}

gomb.addEventListener("click", changeBgColor);
gomb.addEventListener("focus", changeShadowColor);